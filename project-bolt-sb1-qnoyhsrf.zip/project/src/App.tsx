import React, { useState } from 'react';
import { DropletIcon, ClipboardList, BarChart3, FileText, Info } from 'lucide-react';
import Survey from './components/Survey';
import Monitoring from './components/Monitoring';
import Reports from './components/Reports';
import Information from './components/Information';

function App() {
  const [activeTab, setActiveTab] = useState('information');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <DropletIcon className="h-8 w-8 text-blue-500" />
              <span className="ml-2 text-xl font-semibold text-gray-900">WaterWatch India</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => setActiveTab('information')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'information'
                ? 'bg-blue-500 text-white'
                : 'bg-white text-gray-600 hover:bg-blue-50'
            }`}
          >
            <Info className="h-5 w-5 mr-2" />
            Information
          </button>
          <button
            onClick={() => setActiveTab('survey')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'survey'
                ? 'bg-blue-500 text-white'
                : 'bg-white text-gray-600 hover:bg-blue-50'
            }`}
          >
            <ClipboardList className="h-5 w-5 mr-2" />
            Survey
          </button>
          <button
            onClick={() => setActiveTab('monitoring')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'monitoring'
                ? 'bg-blue-500 text-white'
                : 'bg-white text-gray-600 hover:bg-blue-50'
            }`}
          >
            <BarChart3 className="h-5 w-5 mr-2" />
            Monitoring
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              activeTab === 'reports'
                ? 'bg-blue-500 text-white'
                : 'bg-white text-gray-600 hover:bg-blue-50'
            }`}
          >
            <FileText className="h-5 w-5 mr-2" />
            Reports
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          {activeTab === 'information' && <Information />}
          {activeTab === 'survey' && <Survey />}
          {activeTab === 'monitoring' && <Monitoring />}
          {activeTab === 'reports' && <Reports />}
        </div>
      </div>
    </div>
  );
}

export default App;