import React, { useState } from 'react';
import { Send } from 'lucide-react';

function Survey() {
  const [formData, setFormData] = useState({
    location: '',
    waterSource: '',
    waterQuality: '',
    sanitationAccess: '',
    issues: '',
    suggestions: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log(formData);
    alert('Survey submitted successfully!');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Water & Sanitation Survey</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Location</label>
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Primary Water Source</label>
          <select
            name="waterSource"
            value={formData.waterSource}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="">Select an option</option>
            <option value="tap">Tap Water</option>
            <option value="well">Well</option>
            <option value="river">River/Stream</option>
            <option value="rainwater">Rainwater Collection</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Water Quality Rating</label>
          <select
            name="waterQuality"
            value={formData.waterQuality}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="">Select a rating</option>
            <option value="excellent">Excellent</option>
            <option value="good">Good</option>
            <option value="fair">Fair</option>
            <option value="poor">Poor</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Sanitation Access</label>
          <select
            name="sanitationAccess"
            value={formData.sanitationAccess}
            onChange={handleChange}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            required
          >
            <option value="">Select an option</option>
            <option value="full">Full Access</option>
            <option value="limited">Limited Access</option>
            <option value="none">No Access</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Current Issues</label>
          <textarea
            name="issues"
            value={formData.issues}
            onChange={handleChange}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Suggestions for Improvement</label>
          <textarea
            name="suggestions"
            value={formData.suggestions}
            onChange={handleChange}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          className="flex items-center justify-center w-full px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <Send className="h-4 w-4 mr-2" />
          Submit Survey
        </button>
      </form>
    </div>
  );
}

export default Survey;