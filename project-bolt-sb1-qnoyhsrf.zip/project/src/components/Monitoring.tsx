import React from 'react';
import { Droplet, Thermometer, Activity, AlertTriangle } from 'lucide-react';

function Monitoring() {
  const waterQualityData = {
    ph: 7.2,
    turbidity: 1.8,
    temperature: 20,
    contaminants: 0.05
  };

  const alerts = [
    { id: 1, type: 'warning', message: 'Turbidity levels slightly elevated in Zone B' },
    { id: 2, type: 'info', message: 'Scheduled maintenance in 2 days' }
  ];

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Water Quality Monitoring</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-blue-50 p-6 rounded-lg">
          <div className="flex items-center">
            <Droplet className="h-8 w-8 text-blue-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">pH Level</p>
              <p className="text-2xl font-semibold text-gray-900">{waterQualityData.ph}</p>
            </div>
          </div>
        </div>

        <div className="bg-green-50 p-6 rounded-lg">
          <div className="flex items-center">
            <Activity className="h-8 w-8 text-green-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Turbidity</p>
              <p className="text-2xl font-semibold text-gray-900">{waterQualityData.turbidity} NTU</p>
            </div>
          </div>
        </div>

        <div className="bg-orange-50 p-6 rounded-lg">
          <div className="flex items-center">
            <Thermometer className="h-8 w-8 text-orange-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Temperature</p>
              <p className="text-2xl font-semibold text-gray-900">{waterQualityData.temperature}°C</p>
            </div>
          </div>
        </div>

        <div className="bg-red-50 p-6 rounded-lg">
          <div className="flex items-center">
            <AlertTriangle className="h-8 w-8 text-red-500" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Contaminants</p>
              <p className="text-2xl font-semibold text-gray-900">{waterQualityData.contaminants} ppm</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Recent Alerts</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {alerts.map(alert => (
            <div key={alert.id} className="px-6 py-4">
              <div className="flex items-center">
                <AlertTriangle className={`h-5 w-5 ${
                  alert.type === 'warning' ? 'text-yellow-500' : 'text-blue-500'
                }`} />
                <p className="ml-3 text-sm text-gray-600">{alert.message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 p-6 rounded-lg">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Historical Data</h3>
        <div className="h-64 bg-white rounded-lg border border-gray-200">
          {/* Placeholder for charts - In a real application, you would integrate a charting library here */}
          <div className="flex items-center justify-center h-full text-gray-500">
            Historical data visualization would be displayed here
          </div>
        </div>
      </div>
    </div>
  );
}

export default Monitoring;