import React from 'react';
import { Crop as Drop, Shield, Users, AlertTriangle } from 'lucide-react';

function Information() {
  const statistics = [
    {
      id: 1,
      title: "Rural Water Coverage",
      value: "93%",
      description: "of rural India has basic water access",
      icon: Drop,
      color: "blue"
    },
    {
      id: 2,
      title: "Sanitation Coverage",
      value: "99%",
      description: "households have access to toilets",
      icon: Shield,
      color: "green"
    },
    {
      id: 3,
      title: "Population Impact",
      value: "600M+",
      description: "people affected by water stress",
      icon: Users,
      color: "orange"
    },
    {
      id: 4,
      title: "Water Quality",
      value: "70%",
      description: "of water is contaminated",
      icon: AlertTriangle,
      color: "red"
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Water Sanitation & Hygiene in India</h1>
        <p className="text-gray-600">Monitoring and improving water quality across India's diverse regions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statistics.map((stat) => (
          <div key={stat.id} className={`bg-${stat.color}-50 p-6 rounded-lg`}>
            <div className="flex items-center">
              <stat.icon className={`h-8 w-8 text-${stat.color}-500`} />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-500">{stat.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="rounded-lg overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1541011320514-98b2f4626795?auto=format&fit=crop&q=80"
            alt="Water collection in rural India"
            className="w-full h-64 object-cover"
          />
          <div className="bg-white p-4">
            <h3 className="text-lg font-semibold text-gray-900">Rural Water Access</h3>
            <p className="text-gray-600 mt-2">
              Despite significant progress, many rural areas still face challenges in accessing clean drinking water.
              The government's Jal Jeevan Mission aims to provide tap water connections to all rural households.
            </p>
          </div>
        </div>

        <div className="rounded-lg overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1567427017947-545c5f8d16ad?auto=format&fit=crop&q=80"
            alt="Sanitation facility in India"
            className="w-full h-64 object-cover"
          />
          <div className="bg-white p-4">
            <h3 className="text-lg font-semibold text-gray-900">Sanitation Infrastructure</h3>
            <p className="text-gray-600 mt-2">
              The Swachh Bharat Mission has dramatically improved sanitation coverage across India.
              However, maintaining these facilities and ensuring their proper use remains a key focus area.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Key Challenges</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-semibold text-gray-900">Groundwater Depletion</h4>
            <p className="text-gray-600 mt-2">54% of India's groundwater wells are declining in water levels</p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-semibold text-gray-900">Water Quality</h4>
            <p className="text-gray-600 mt-2">High levels of fluoride, arsenic, and heavy metals in many regions</p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-semibold text-gray-900">Infrastructure</h4>
            <p className="text-gray-600 mt-2">Aging distribution systems leading to significant water loss</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <img 
          src="https://images.unsplash.com/photo-1464207687429-7505649dae38?auto=format&fit=crop&q=80"
          alt="Water conservation"
          className="w-full h-48 object-cover rounded-lg"
        />
        <img 
          src="https://images.unsplash.com/photo-1543651425-3278ee8626a8?auto=format&fit=crop&q=80"
          alt="Community involvement"
          className="w-full h-48 object-cover rounded-lg"
        />
        <img 
          src="https://images.unsplash.com/photo-1551731409-43eb3e517a1b?auto=format&fit=crop&q=80"
          alt="Water testing"
          className="w-full h-48 object-cover rounded-lg"
        />
      </div>
    </div>
  );
}

export default Information;