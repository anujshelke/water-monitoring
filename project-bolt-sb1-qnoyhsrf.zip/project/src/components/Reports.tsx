import React from 'react';
import { FileText, Download, Filter } from 'lucide-react';

function Reports() {
  const reports = [
    {
      id: 1,
      title: 'Monthly Water Quality Report',
      date: '2024-02-01',
      type: 'Water Quality',
      status: 'Complete'
    },
    {
      id: 2,
      title: 'Sanitation Infrastructure Assessment',
      date: '2024-01-15',
      type: 'Infrastructure',
      status: 'Complete'
    },
    {
      id: 3,
      title: 'Community Feedback Analysis',
      date: '2024-01-01',
      type: 'Community',
      status: 'In Progress'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Reports & Analysis</h2>
        <button className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
          <Filter className="h-4 w-4 mr-2" />
          Filter
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Report Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {reports.map((report) => (
                <tr key={report.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-gray-400 mr-2" />
                      <div className="text-sm font-medium text-gray-900">{report.title}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{report.date}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{report.type}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      report.status === 'Complete' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {report.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button className="flex items-center text-blue-500 hover:text-blue-700">
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Key Findings</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-green-500"></div>
              <p className="ml-3 text-sm text-gray-600">95% of water samples meet quality standards</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-yellow-500"></div>
              <p className="ml-3 text-sm text-gray-600">Infrastructure maintenance needed in 3 locations</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-blue-500"></div>
              <p className="ml-3 text-sm text-gray-600">Community satisfaction increased by 15%</p>
            </li>
          </ul>
        </div>

        <div className="bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recommendations</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-red-500"></div>
              <p className="ml-3 text-sm text-gray-600">Upgrade filtration systems in Zone C</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-purple-500"></div>
              <p className="ml-3 text-sm text-gray-600">Implement water conservation programs</p>
            </li>
            <li className="flex items-start">
              <div className="flex-shrink-0 h-2 w-2 mt-2 rounded-full bg-indigo-500"></div>
              <p className="ml-3 text-sm text-gray-600">Schedule community awareness workshops</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Reports;